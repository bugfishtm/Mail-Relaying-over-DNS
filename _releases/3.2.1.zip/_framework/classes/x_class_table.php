<?php 
	/* 	
		@@@@@@@   @@@  @@@   @@@@@@@@  @@@@@@@@  @@@   @@@@@@   @@@  @@@  
		@@@@@@@@  @@@  @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@@@@@   @@@  @@@  
		@@!  @@@  @@!  @@@  !@@        @@!       @@!  !@@       @@!  @@@  
		!@   @!@  !@!  @!@  !@!        !@!       !@!  !@!       !@!  @!@  
		@!@!@!@   @!@  !@!  !@! @!@!@  @!!!:!    !!@  !!@@!!    @!@!@!@!  
		!!!@!!!!  !@!  !!!  !!! !!@!!  !!!!!:    !!!   !!@!!!   !!!@!!!!  
		!!:  !!!  !!:  !!!  :!!   !!:  !!:       !!:       !:!  !!:  !!!  
		:!:  !:!  :!:  !:!  :!:   !::  :!:       :!:      !:!   :!:  !:!  
		 :: ::::  ::::: ::   ::: ::::   ::        ::  :::: ::   ::   :::  
		:: : ::    : :  :    :: :: :    :        :    :: : :     :   : :  
		   ____         _     __                      __  __         __           __  __
		  /  _/ _    __(_)__ / /    __ _____  __ __  / /_/ /  ___   / /  ___ ___ / /_/ /
		 _/ /  | |/|/ / (_-</ _ \  / // / _ \/ // / / __/ _ \/ -_) / _ \/ -_|_-</ __/_/ 
		/___/  |__,__/_/___/_//_/  \_, /\___/\_,_/  \__/_//_/\__/ /_.__/\__/___/\__(_)  
								  /___/                           
		Bugfish Framework Codebase // MIT License
		// Autor: Jan-Maurice Dahlmanns (Bugfish)
		// Website: www.bugfish.eu 
	*/
/*	class x_class_mysql_relation {
		// Class Variables
		private $mysql     				= false;
		
		// Constructor
		function __construct($mysql) {}		
		
		public function table_spawn() {
			echo '<table class="x_class_table x_class_table_'.'">';
				echo '<thead class="x_class_table">';
					echo '<tr>';
						//foreach($this->title_array as $key => $value) {
							echo '<th>';
								echo $value;
							echo '</th>';
						//}
					echo '</tr>';
				echo '</thead>';
				echo '<tbody class="x_class_table">';
					//foreach($this->value_array as $key => $value) {
						echo '<tr>';
							//foreach($value as $keyx => $valuex) {
								echo '<td>';
									
								echo '</td>';
							//}
						echo '</tr>';
					//}
				echo '</tbody>';
			echo '</table>';
		}
	}
*/