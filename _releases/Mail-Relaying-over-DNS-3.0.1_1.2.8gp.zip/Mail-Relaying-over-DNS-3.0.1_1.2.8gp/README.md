
# Mail Relaying over DNS [MRoD]

For Documentation take a look at the index.html file in the docs directory! You can open it with any webbrowser...

You can find the Documentation here:  
https://bugfishtm.github.io/Mail-Relaying-over-DNS/  

You can find the Github Project here:  
https://github.com/bugfishtm/Mail-Relaying-over-DNS  


I am planning to make a youtube turorial video about this software. See my channels page for the video - It should be named like this project is.   
My Channel URL is here:  
https://www.youtube.com/channel/UC3cOjFu-MLj8GGDkpeIhqhQ

The place where i usually store such kind of tutorial videos is here:  
https://www.youtube.com/playlist?list=PL6npOHuBGrpBw4hKaalqa1E8tGNNf8KoO
  
If you fo not find a tutorial video inside this playlist, i advise you to keep on using the manual/readme at the github page or my website for help.

My General Github Project Page is here:  
https://bugfishtm.github.io


## Default Login for Webinterface
Username: admin  
Passwort: changeme

## Issues
if you encounter issues or have questions using this software, do not hesitate write us at our forum on www.bugfish.eu!

----------------------------------------------------------------
##### more at www.bugfish.eu 
  
Made by Jan-Maurice Dahlmanns
  